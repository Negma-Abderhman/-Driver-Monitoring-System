﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.Services;
using UpdateDriverMonitoring.API.DTOs;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationsController : ControllerBase
    {
        private readonly NotificationService _service;

        public NotificationsController(NotificationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<List<NotificationDto>>> GetAll()
        {
            var notifications = await _service.GetAllNotificationsAsync();

            var dtos = notifications.Select(n => new NotificationDto
            {
                Id = n.Id,
                Message = n.Message,
                Type = n.Type.ToString(),
                IsRead = n.IsRead,
                CreatedAt = n.CreatedAt,
                CreatedBy = n.CreatedBy,
                ExpireAt = n.ExpireAt,
                DriverId = n.DriverId
            }).ToList();

            return Ok(dtos);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<NotificationDto>> GetById(int id)
        {
            var n = await _service.GetNotificationByIdAsync(id);
            if (n == null) return NotFound();

            var dto = new NotificationDto
            {
                Id = n.Id,
                Message = n.Message,
                Type = n.Type.ToString(),
                IsRead = n.IsRead,
                CreatedAt = n.CreatedAt,
                CreatedBy = n.CreatedBy,
                ExpireAt = n.ExpireAt,
                DriverId = n.DriverId
            };

            return Ok(dto);
        }

        [HttpPost]
        public async Task<ActionResult<NotificationDto>> Create([FromBody] NotificationDto notificationDto)
        {
            var notification = new Notification
            {
                Message = notificationDto.Message,
                Type = Enum.TryParse(notificationDto.Type, out NotificationType type) ? type : NotificationType.Info,
                IsRead = notificationDto.IsRead,
                CreatedAt = notificationDto.CreatedAt,
                CreatedBy = notificationDto.CreatedBy,
                ExpireAt = notificationDto.ExpireAt,
                DriverId = notificationDto.DriverId
            };

            var created = await _service.CreateNotificationAsync(notification);

            var dto = new NotificationDto
            {
                Id = created.Id,
                Message = created.Message,
                Type = created.Type.ToString(),
                IsRead = created.IsRead,
                CreatedAt = created.CreatedAt,
                CreatedBy = created.CreatedBy,
                ExpireAt = created.ExpireAt,
                DriverId = created.DriverId
            };

            return CreatedAtAction(nameof(GetById), new { id = dto.Id }, dto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] NotificationDto notificationDto)
        {
            var notification = new Notification
            {
                Id = id,
                Message = notificationDto.Message,
                Type = Enum.TryParse(notificationDto.Type, out NotificationType type) ? type : NotificationType.Info,
                IsRead = notificationDto.IsRead,
                CreatedAt = notificationDto.CreatedAt,
                CreatedBy = notificationDto.CreatedBy,
                ExpireAt = notificationDto.ExpireAt,
                DriverId = notificationDto.DriverId
            };

            var updated = await _service.UpdateNotificationAsync(id, notification);
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _service.DeleteNotificationAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
