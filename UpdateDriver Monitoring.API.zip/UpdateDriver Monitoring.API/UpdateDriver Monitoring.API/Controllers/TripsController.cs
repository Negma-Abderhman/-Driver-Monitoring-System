﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitorin.API.DTOs;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.Services;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TripsController : ControllerBase
    {
        private readonly TripsService _service;
        private readonly DriverMonitoringContext _context;

        public TripsController(TripsService service, DriverMonitoringContext context)
        {
            _service = service;
            _context = context;
        }

        
        [HttpGet]
        public async Task<ActionResult<List<TripDto>>> GetAll()
        {
            var trips = await _service.GetAllTripsAsync();

            var dtos = trips.Select(t => new TripDto
            {
                Id = t.Id,
                StartTime = t.StartTime,
                EndTime = t.EndTime,
                StartLatitude = t.StartLatitude,
                StartLongitude = t.StartLongitude,
                EndLatitude = t.EndLatitude,
                EndLongitude = t.EndLongitude,
                DistanceKm = t.DistanceKm,
                AverageSpeedKph = t.AverageSpeedKph,
                MaxSpeedKph = t.MaxSpeedKph,
                Status = t.Status.ToString(),
                DriverId = t.DriverId,
                VehicleId = t.VehicleId,
                DurationHours = t.Duration?.TotalHours
            }).ToList();

            return Ok(dtos);
        }

        
        [HttpGet("{id}")]
        public async Task<ActionResult<TripDto>> GetById(int id)
        {
            var trip = await _service.GetTripByIdAsync(id);
            if (trip == null) return NotFound();

            var dto = new TripDto
            {
                Id = trip.Id,
                StartTime = trip.StartTime,
                EndTime = trip.EndTime,
                StartLatitude = trip.StartLatitude,
                StartLongitude = trip.StartLongitude,
                EndLatitude = trip.EndLatitude,
                EndLongitude = trip.EndLongitude,
                DistanceKm = trip.DistanceKm,
                AverageSpeedKph = trip.AverageSpeedKph,
                MaxSpeedKph = trip.MaxSpeedKph,
                Status = trip.Status.ToString(),
                DriverId = trip.DriverId,
                VehicleId = trip.VehicleId,
                DurationHours = trip.Duration?.TotalHours
            };

            return Ok(dto);
        }

        
        [HttpPost]
        public async Task<ActionResult<TripDto>> Create([FromBody] TripDto tripDto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var driver = await _context.Drivers.FindAsync(tripDto.DriverId);
            if (driver == null)
                return BadRequest(new { message = "Invalid DriverId" });

            var vehicle = await _context.Vehicles.FindAsync(tripDto.VehicleId);
            if (vehicle == null)
                return BadRequest(new { message = "Invalid VehicleId" });

            var trip = new Trip
            {
                StartTime = tripDto.StartTime,
                EndTime = tripDto.EndTime,
                StartLatitude = tripDto.StartLatitude,
                StartLongitude = tripDto.StartLongitude,
                EndLatitude = tripDto.EndLatitude,
                EndLongitude = tripDto.EndLongitude,
                DistanceKm = tripDto.DistanceKm,
                AverageSpeedKph = tripDto.AverageSpeedKph,
                MaxSpeedKph = tripDto.MaxSpeedKph,
                Status = Enum.TryParse<TripStatus>(tripDto.Status, true, out var status)
                            ? status
                            : TripStatus.Ongoing,
                DriverId = tripDto.DriverId,
                VehicleId = tripDto.VehicleId
            };

            var created = await _service.CreateTripAsync(trip);

            tripDto.Id = created.Id;
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, tripDto);
        }

        
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] TripDto tripDto)
        {
            var driver = await _context.Drivers.FindAsync(tripDto.DriverId);
            var vehicle = await _context.Vehicles.FindAsync(tripDto.VehicleId);

            if (driver == null || vehicle == null)
                return BadRequest(new { message = "Invalid DriverId or VehicleId" });

            var trip = new Trip
            {
                Id = id,
                StartTime = tripDto.StartTime,
                EndTime = tripDto.EndTime,
                StartLatitude = tripDto.StartLatitude,
                StartLongitude = tripDto.StartLongitude,
                EndLatitude = tripDto.EndLatitude,
                EndLongitude = tripDto.EndLongitude,
                DistanceKm = tripDto.DistanceKm,
                AverageSpeedKph = tripDto.AverageSpeedKph,
                MaxSpeedKph = tripDto.MaxSpeedKph,
                Status = Enum.TryParse<TripStatus>(tripDto.Status, true, out var status)
                            ? status
                            : TripStatus.Ongoing,
                DriverId = tripDto.DriverId,
                VehicleId = tripDto.VehicleId
            };

            var updated = await _service.UpdateTripAsync(id, trip);
            if (!updated) return NotFound();

            return NoContent();
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _service.DeleteTripAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
