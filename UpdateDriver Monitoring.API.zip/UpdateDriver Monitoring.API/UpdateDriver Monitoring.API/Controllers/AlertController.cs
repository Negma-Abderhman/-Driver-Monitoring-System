﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitoring.API.DTOs;
using UpdateDriverMonitoring.API.Services;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlertsController : ControllerBase
    {
        private readonly AlertService _service;

        public AlertsController(AlertService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<List<AlertDto>>> GetAll() => Ok(await _service.GetAllAlertsAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<AlertDto>> GetById(int id)
        {
            var alert = await _service.GetAlertByIdAsync(id);
            if (alert == null) return NotFound();
            return Ok(alert);
        }

        [HttpPost]
        public async Task<ActionResult<AlertDto>> Create([FromBody] AlertDto alert)
        {
            var created = await _service.CreateAlertAsync(alert);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] AlertDto alert)
        {
            var updated = await _service.UpdateAlertAsync(id, alert);
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _service.DeleteAlertAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
