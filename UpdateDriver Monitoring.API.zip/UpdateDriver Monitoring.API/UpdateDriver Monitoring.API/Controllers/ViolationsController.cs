﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.Services;
using UpdateDriverMonitorin.API.DTOs; 
namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ViolationsController : ControllerBase
    {
        private readonly ViolationService _service;

        public ViolationsController(ViolationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<List<ViolationDto>>> GetAll()
        {
            var violations = await _service.GetAllViolationsAsync();
            var dtoList = violations.Select(v => new ViolationDto
            {
                Id = v.Id,
                Type = v.Type,
                Description = v.Description,
                Severity = v.Severity,
                FineAmount = v.FineAmount,
                OccurredAt = v.OccurredAt,
                DriverId = v.DriverId,
                DriverName = v.Driver?.FullName ?? "",
                TripId = v.TripId
            }).ToList();

            return Ok(dtoList);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ViolationDto>> GetById(int id)
        {
            var v = await _service.GetViolationByIdAsync(id);
            if (v == null) return NotFound();

            var dto = new ViolationDto
            {
                Id = v.Id,
                Type = v.Type,
                Description = v.Description,
                Severity = v.Severity,
                FineAmount = v.FineAmount,
                OccurredAt = v.OccurredAt,
                DriverId = v.DriverId,
                DriverName = v.Driver?.FullName ?? "",
                TripId = v.TripId
            };

            return Ok(dto);
        }

        [HttpPost]
        public async Task<ActionResult<ViolationDto>> Create([FromBody] Violation violation)
        {
            var created = await _service.CreateViolationAsync(violation);

            var dto = new ViolationDto
            {
                Id = created.Id,
                Type = created.Type,
                Description = created.Description,
                Severity = created.Severity,
                FineAmount = created.FineAmount,
                OccurredAt = created.OccurredAt,
                DriverId = created.DriverId,
                DriverName = created.Driver?.FullName ?? "",
                TripId = created.TripId
            };

            return CreatedAtAction(nameof(GetById), new { id = dto.Id }, dto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Violation violation)
        {
            var updated = await _service.UpdateViolationAsync(id, violation);
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _service.DeleteViolationAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
