﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.Services;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehiclesController : ControllerBase
    {
        private readonly VehicleService _service;

        public VehiclesController(VehicleService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<List<Vehicle>>> GetAll() => Ok(await _service.GetAllVehiclesAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<Vehicle>> GetById(int id)
        {
            var vehicle = await _service.GetVehicleByIdAsync(id);
            if (vehicle == null) return NotFound();
            return Ok(vehicle);
        }

        [HttpPost]
        public async Task<ActionResult<Vehicle>> Create([FromBody] Vehicle vehicle)
        {
            var created = await _service.CreateVehicleAsync(vehicle);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Vehicle vehicle)
        {
            var updated = await _service.UpdateVehicleAsync(id, vehicle);
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _service.DeleteVehicleAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
