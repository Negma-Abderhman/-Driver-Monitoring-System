﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitorin.API.DTOs;
using UpdateDriverMonitoring.API.DTOs;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.Services;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationsController : ControllerBase
    {
        private readonly LocationService _service;

        public LocationsController(LocationService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<List<LocationDto>>> GetAll()
        {
            var locations = await _service.GetAllLocationsAsync();

            var dtos = locations.Select(l => new LocationDto
            {
                Id = l.Id,
                Latitude = l.Latitude,
                Longitude = l.Longitude,
                SpeedKph = l.SpeedKph,
                Direction = l.Direction,
                AccuracyMeters = l.AccuracyMeters,
                RecordedAt = l.RecordedAt,
                TripId = l.TripId
            }).ToList();

            return Ok(dtos);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<LocationDto>> GetById(int id)
        {
            var l = await _service.GetLocationByIdAsync(id);
            if (l == null) return NotFound();

            var dto = new LocationDto
            {
                Id = l.Id,
                Latitude = l.Latitude,
                Longitude = l.Longitude,
                SpeedKph = l.SpeedKph,
                Direction = l.Direction,
                AccuracyMeters = l.AccuracyMeters,
                RecordedAt = l.RecordedAt,
                TripId = l.TripId
            };

            return Ok(dto);
        }

        [HttpPost]
        public async Task<ActionResult<LocationDto>> Create([FromBody] LocationDto locationDto)
        {
            var location = new Location
            {
                Latitude = locationDto.Latitude,
                Longitude = locationDto.Longitude,
                SpeedKph = locationDto.SpeedKph,
                Direction = locationDto.Direction,
                AccuracyMeters = locationDto.AccuracyMeters,
                RecordedAt = locationDto.RecordedAt,
                TripId = locationDto.TripId
            };

            var created = await _service.CreateLocationAsync(location);

            locationDto.Id = created.Id;
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, locationDto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] LocationDto locationDto)
        {
            var location = new Location
            {
                Id = id,
                Latitude = locationDto.Latitude,
                Longitude = locationDto.Longitude,
                SpeedKph = locationDto.SpeedKph,
                Direction = locationDto.Direction,
                AccuracyMeters = locationDto.AccuracyMeters,
                RecordedAt = locationDto.RecordedAt,
                TripId = locationDto.TripId
            };

            var updated = await _service.UpdateLocationAsync(id, location);
            if (!updated) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _service.DeleteLocationAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
