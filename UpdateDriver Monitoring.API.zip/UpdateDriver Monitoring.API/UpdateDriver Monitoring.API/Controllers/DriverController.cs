﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.Services;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriversController : ControllerBase
    {
        private readonly DriverService _service;

        public DriversController(DriverService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<List<Driver>>> GetAll()
        {
            var drivers = await _service.GetAllDriversAsync();
            return Ok(drivers);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Driver>> GetById(int id)
        {
            var driver = await _service.GetDriverByIdAsync(id);
            if (driver == null) return NotFound();
            return Ok(driver);
        }

        [HttpPost]
        public async Task<ActionResult<Driver>> Create([FromBody] Driver driver)
        {
            var created = await _service.CreateDriverAsync(driver);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Driver driver)
        {
            var result = await _service.UpdateDriverAsync(id, driver);
            if (!result) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _service.DeleteDriverAsync(id);
            if (!result) return NotFound();
            return NoContent();
        }
    }
}
