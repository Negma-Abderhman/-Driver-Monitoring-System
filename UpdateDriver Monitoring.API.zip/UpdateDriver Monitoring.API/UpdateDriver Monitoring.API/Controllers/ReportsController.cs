﻿using Microsoft.AspNetCore.Mvc;
using UpdateDriverMonitoring.API.Services;
using UpdateDriverMonitoring.API.DTOs;

namespace UpdateDriverMonitoring.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController : ControllerBase
    {
        private readonly ReportsService _reportsService;

        public ReportsController(ReportsService reportsService)
        {
            _reportsService = reportsService;
        }

        
        [HttpGet("drivers-summary")]
        public async Task<ActionResult<List<DriverSummaryDto>>> GetAllDriversSummary()
        {
            var summaries = await _reportsService.GetAllDriversSummaryAsync();
            var dtoList = summaries.Select(d => new DriverSummaryDto
            {
                DriverId = d.DriverId,
                FullName = d.FullName,
                TotalTrips = d.TotalTrips,
                TotalDistanceKm = d.TotalDistanceKm,
                TotalViolations = d.TotalViolations,
                AverageSpeedKph = d.AverageSpeedKph
            }).ToList();

            return Ok(dtoList);
        }

        
        [HttpGet("driver-summary/{driverId}")]
        public async Task<ActionResult<DriverSummaryDto>> GetDriverSummary(int driverId)
        {
            var summary = await _reportsService.GetDriverSummaryByIdAsync(driverId);
            if (summary == null) return NotFound();

            var dto = new DriverSummaryDto
            {
                DriverId = summary.DriverId,
                FullName = summary.FullName,
                TotalTrips = summary.TotalTrips,
                TotalDistanceKm = summary.TotalDistanceKm,
                TotalViolations = summary.TotalViolations,
                AverageSpeedKph = summary.AverageSpeedKph
            };

            return Ok(dto);
        }

        
        [HttpGet("daily-report")]
        public async Task<ActionResult<List<object>>> GetDailyReport([FromQuery] DateTime date)
        {
            var report = await _reportsService.GetDailyReportAsync(date);
            return Ok(report);
        }

        
        [HttpGet("violations-report")]
        public async Task<ActionResult<List<object>>> GetViolationsReport()
        {
            var report = await _reportsService.GetViolationsReportAsync();
            return Ok(report);
        }
    }
}
