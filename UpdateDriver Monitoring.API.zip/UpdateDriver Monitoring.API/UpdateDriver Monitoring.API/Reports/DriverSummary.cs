﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;

namespace UpdateDriverMonitoring.API.Reports
{
    public class DriverSummary
    {
        public int DriverId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public int TotalTrips { get; set; }
        public double TotalDistanceKm { get; set; }
        public int TotalViolations { get; set; }
        public double AverageSpeedKph { get; set; }
    }

    public class DriverSummaryReport
    {
        private readonly DriverMonitoringContext _context;

        public DriverSummaryReport(DriverMonitoringContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        
        public async Task<List<DriverSummary>> GetAllDriversSummaryAsync()
        {
            return await _context.Drivers
                .AsNoTracking()
                .Select(d => new DriverSummary
                {
                    DriverId = d.Id,
                    FullName = d.FullName,
                    TotalTrips = d.Trips.Count(),
                    TotalDistanceKm = d.Trips.Sum(t => (double?)t.DistanceKm) ?? 0,
                    TotalViolations = d.Violations.Count(),
                    AverageSpeedKph = d.Trips.Any() ? d.Trips.Average(t => t.AverageSpeedKph ?? 0) : 0
                })
                .ToListAsync();
        }

        
        public async Task<DriverSummary?> GetDriverSummaryByIdAsync(int driverId)
        {
            return await _context.Drivers
                .AsNoTracking()
                .Where(d => d.Id == driverId)
                .Select(d => new DriverSummary
                {
                    DriverId = d.Id,
                    FullName = d.FullName,
                    TotalTrips = d.Trips.Count(),
                    TotalDistanceKm = d.Trips.Sum(t => (double?)t.DistanceKm) ?? 0,
                    TotalViolations = d.Violations.Count(),
                    AverageSpeedKph = d.Trips.Any() ? d.Trips.Average(t => t.AverageSpeedKph ?? 0) : 0
                })
                .FirstOrDefaultAsync();
        }
    }
} 

