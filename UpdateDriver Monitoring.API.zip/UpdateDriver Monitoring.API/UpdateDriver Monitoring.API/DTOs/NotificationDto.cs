﻿using System;

namespace UpdateDriverMonitoring.API.DTOs
{
    public class NotificationDto
    {
        public int Id { get; set; }
        public string Message { get; set; } = string.Empty;
        public string Type { get; set; } = "Info"; 
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? ExpireAt { get; set; }
        public int DriverId { get; set; }  
    }
}
