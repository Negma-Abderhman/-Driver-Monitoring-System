﻿using System;
using System.Text.Json.Serialization;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitorin.API.DTOs
{
    public class ViolationDto
    {
        public int Id { get; set; }

        
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public ViolationType Type { get; set; }

        public string Description { get; set; } = string.Empty;

        [JsonConverter(typeof(JsonStringEnumConverter))]
        public SeverityLevel Severity { get; set; } = SeverityLevel.Low;

        public decimal? FineAmount { get; set; }

        public DateTime OccurredAt { get; set; }

        public int DriverId { get; set; }

        public string DriverName { get; set; } = string.Empty;

        public int? TripId { get; set; }
    }
}
