﻿using System;

namespace UpdateDriverMonitoring.API.DTOs
{
    public class LocationDto
    {
        public int Id { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double? SpeedKph { get; set; }
        public double? Direction { get; set; }
        public double? AccuracyMeters { get; set; }
        public DateTime RecordedAt { get; set; }
        public int TripId { get; set; }
    }
}
