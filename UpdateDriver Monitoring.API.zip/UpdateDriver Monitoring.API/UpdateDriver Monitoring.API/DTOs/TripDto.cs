﻿using System;

namespace UpdateDriverMonitorin.API.DTOs
{
    public class TripDto
    {
        public int Id { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }

        public double? StartLatitude { get; set; }
        public double? StartLongitude { get; set; }
        public double? EndLatitude { get; set; }
        public double? EndLongitude { get; set; }

        public double? DistanceKm { get; set; }
        public double? AverageSpeedKph { get; set; }
        public double? MaxSpeedKph { get; set; }
        public string Status { get; set; } = "Ongoing"; 

        public int DriverId { get; set; }
        public int VehicleId { get; set; }

        
        public double? DurationHours { get; set; }
    }
}
