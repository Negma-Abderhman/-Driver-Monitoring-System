﻿namespace UpdateDriverMonitoring.API.DTOs
{
    public class DriverSummaryDto
    {
        public int DriverId { get; set; }
        public string FullName { get; set; } = string.Empty;
        public int TotalTrips { get; set; }
        public double TotalDistanceKm { get; set; }
        public int TotalViolations { get; set; }
        public double AverageSpeedKph { get; set; }
    }
}
