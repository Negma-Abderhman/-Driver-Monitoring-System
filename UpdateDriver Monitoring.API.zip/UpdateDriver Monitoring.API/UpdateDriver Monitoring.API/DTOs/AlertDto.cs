﻿using System;

namespace UpdateDriverMonitoring.API.DTOs
{
    public class AlertDto
    {
        public int Id { get; set; }
        public string Type { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string Severity { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public bool Acknowledged { get; set; }
        public DateTime? AcknowledgedAt { get; set; }

        public int? DriverId { get; set; }
        public int? TripId { get; set; }
        public int? ViolationId { get; set; }
    }
}
