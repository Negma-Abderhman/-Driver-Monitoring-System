﻿using System;

namespace UpdateDriverMonitorin.API.DTOs

{
    public class VehicleDto
    {
        public int Id { get; set; }
        public string PlateNumber { get; set; } = string.Empty;
        public string Make { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int? Year { get; set; }
        public string? Color { get; set; }
        public string? VIN { get; set; }
        public string Status { get; set; } = "Active"; 
        public double? MileageKm { get; set; }
        public DateTime? LastServiceDate { get; set; }
    }
}
