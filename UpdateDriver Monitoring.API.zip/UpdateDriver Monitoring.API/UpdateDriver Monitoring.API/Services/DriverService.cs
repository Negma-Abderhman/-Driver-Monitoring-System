﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Services
{
    public class DriverService
    {
        private readonly DriverMonitoringContext _context;

        public DriverService(DriverMonitoringContext context)
        {
            _context = context;
        }

        public async Task<List<Driver>> GetAllDriversAsync()
        {
            return await _context.Drivers.AsNoTracking().ToListAsync();
        }

        public async Task<Driver?> GetDriverByIdAsync(int id)
        {
            return await _context.Drivers.AsNoTracking().FirstOrDefaultAsync(d => d.Id == id);
        }

        public async Task<Driver> CreateDriverAsync(Driver driver)
        {
            _context.Drivers.Add(driver);
            await _context.SaveChangesAsync();
            return driver;
        }

        public async Task<bool> UpdateDriverAsync(int id, Driver driver)
        {
            var existingDriver = await _context.Drivers.FindAsync(id);
            if (existingDriver == null) return false;

            
            existingDriver.FullName = driver.FullName;
            existingDriver.LicenseNumber = driver.LicenseNumber;
            existingDriver.PhoneNumber = driver.PhoneNumber;
            existingDriver.Email = driver.Email;
            existingDriver.Status = driver.Status;
            existingDriver.PhotoUrl = driver.PhotoUrl;
            existingDriver.DateOfBirth = driver.DateOfBirth;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteDriverAsync(int id)
        {
            var driver = await _context.Drivers.FindAsync(id);
            if (driver == null) return false;

            _context.Drivers.Remove(driver);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
