﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Services
{
    public class NotificationService
    {
        private readonly DriverMonitoringContext _context;

        public NotificationService(DriverMonitoringContext context)
        {
            _context = context;
        }

        public async Task<List<Notification>> GetAllNotificationsAsync()
        {
            return await _context.Notifications
                                 .Include(n => n.Driver)
                                 .AsNoTracking()
                                 .ToListAsync();
        }

        public async Task<Notification?> GetNotificationByIdAsync(int id)
        {
            return await _context.Notifications
                                 .Include(n => n.Driver)
                                 .AsNoTracking()
                                 .FirstOrDefaultAsync(n => n.Id == id);
        }

        public async Task<Notification> CreateNotificationAsync(Notification notification)
        {
            _context.Notifications.Add(notification);
            await _context.SaveChangesAsync();
            return notification;
        }

        public async Task<bool> UpdateNotificationAsync(int id, Notification notification)
        {
            if (id != notification.Id) return false;

            _context.Entry(notification).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Notifications.Any(e => e.Id == id))
                    return false;
                throw;
            }
        }

        public async Task<bool> DeleteNotificationAsync(int id)
        {
            var notification = await _context.Notifications.FindAsync(id);
            if (notification == null) return false;

            _context.Notifications.Remove(notification);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
