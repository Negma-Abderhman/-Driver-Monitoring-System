﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Services
{
    public class ViolationService
    {
        private readonly DriverMonitoringContext _context;

        public ViolationService(DriverMonitoringContext context)
        {
            _context = context;
        }

        public async Task<List<Violation>> GetAllViolationsAsync()
        {
            return await _context.Violations
                                 .Include(v => v.Driver)
                                 .Include(v => v.Trip)
                                 .AsNoTracking()
                                 .ToListAsync();
        }

        public async Task<Violation?> GetViolationByIdAsync(int id)
        {
            return await _context.Violations
                                 .Include(v => v.Driver)
                                 .Include(v => v.Trip)
                                 .AsNoTracking()
                                 .FirstOrDefaultAsync(v => v.Id == id);
        }

        public async Task<Violation> CreateViolationAsync(Violation violation)
        {
            _context.Violations.Add(violation);
            await _context.SaveChangesAsync();
            return violation;
        }

        public async Task<bool> UpdateViolationAsync(int id, Violation violation)
        {
            if (id != violation.Id) return false;

            _context.Entry(violation).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Violations.Any(v => v.Id == id))
                    return false;
                throw;
            }
        }

        public async Task<bool> DeleteViolationAsync(int id)
        {
            var violation = await _context.Violations.FindAsync(id);
            if (violation == null) return false;

            _context.Violations.Remove(violation);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
