﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Reports;

namespace UpdateDriverMonitoring.API.Services
{
    public class ReportsService
    {
        private readonly DriverMonitoringContext _context;
        private readonly DriverSummaryReport _driverSummaryReport;

        public ReportsService(DriverMonitoringContext context)
        {
            _context = context;
            _driverSummaryReport = new DriverSummaryReport(_context);
        }

        
        public async Task<DriverSummary?> GetDriverSummaryByIdAsync(int driverId)
        {
            return await _driverSummaryReport.GetDriverSummaryByIdAsync(driverId);
        }

        public async Task<List<DriverSummary>> GetAllDriversSummaryAsync()
        {
            return await _driverSummaryReport.GetAllDriversSummaryAsync();
        }

        public async Task<List<object>> GetDailyReportAsync(DateTime date)
        {
            var trips = await _context.Trips
                .Include(t => t.Driver)
                .Include(t => t.Vehicle)
                .Where(t => t.StartTime.Date == date.Date)
                .AsNoTracking()
                .ToListAsync();

            return trips.Select(t => new
            {
                TripId = t.Id,
                DriverId = t.DriverId,
                DriverName = t.Driver.FullName,
                VehiclePlate = t.Vehicle.PlateNumber,
                DistanceKm = t.DistanceKm,
                AverageSpeedKph = t.AverageSpeedKph,
                MaxSpeedKph = t.MaxSpeedKph,
                StartTime = t.StartTime,
                EndTime = t.EndTime,
                DurationMinutes = t.Duration.HasValue ? (int)t.Duration.Value.TotalMinutes : (int?)null
            }).ToList<object>();
        }

        public async Task<List<object>> GetViolationsReportAsync()
        {
            var violations = await _context.Violations
                .Include(v => v.Driver)
                .Include(v => v.Trip)
                    .ThenInclude(t => t.Vehicle)
                .AsNoTracking()
                .OrderByDescending(v => v.OccurredAt)
                .ToListAsync();

            return violations.Select(v => new
            {
                ViolationId = v.Id,
                DriverId = v.DriverId,
                DriverName = v.Driver.FullName,
                VehiclePlate = v.Trip != null ? v.Trip.Vehicle.PlateNumber : null,
                Type = v.Type,
                Severity = v.Severity,
                FineAmount = v.FineAmount,
                OccurredAt = v.OccurredAt
            }).ToList<object>();
        }
    }
}
