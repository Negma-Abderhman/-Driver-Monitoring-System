﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Models;
using UpdateDriverMonitoring.API.DTOs;

namespace UpdateDriverMonitoring.API.Services
{
    public class AlertService
    {
        private readonly DriverMonitoringContext _context;

        public AlertService(DriverMonitoringContext context)
        {
            _context = context;
        }

        
        public async Task<List<AlertDto>> GetAllAlertsAsync()
        {
            return await _context.Alerts
                .AsNoTracking()
                .Select(a => new AlertDto
                {
                    Id = a.Id,
                    Type = a.Type.ToString(),        
                    Message = a.Message,
                    Severity = a.Severity.ToString(), 
                    CreatedAt = a.CreatedAt,
                    Acknowledged = a.Acknowledged,
                    AcknowledgedAt = a.AcknowledgedAt,
                    DriverId = a.DriverId,
                    TripId = a.TripId,
                    ViolationId = a.ViolationId
                })
                .ToListAsync();
        }

        
        public async Task<AlertDto?> GetAlertByIdAsync(int id)
        {
            return await _context.Alerts
                .AsNoTracking()
                .Where(a => a.Id == id)
                .Select(a => new AlertDto
                {
                    Id = a.Id,
                    Type = a.Type.ToString(),
                    Message = a.Message,
                    Severity = a.Severity.ToString(),
                    CreatedAt = a.CreatedAt,
                    Acknowledged = a.Acknowledged,
                    AcknowledgedAt = a.AcknowledgedAt,
                    DriverId = a.DriverId,
                    TripId = a.TripId,
                    ViolationId = a.ViolationId
                })
                .FirstOrDefaultAsync();
        }

        
        public async Task<AlertDto> CreateAlertAsync(AlertDto alertDto)
        {
            var alert = new Alert
            {
                Type = Enum.Parse<AlertType>(alertDto.Type),
                Message = alertDto.Message,
                Severity = Enum.Parse<SeverityLevel>(alertDto.Severity),
                CreatedAt = DateTime.UtcNow,
                Acknowledged = false,
                DriverId = alertDto.DriverId,
                TripId = alertDto.TripId,
                ViolationId = alertDto.ViolationId
            };

            _context.Alerts.Add(alert);
            await _context.SaveChangesAsync();

            
            alertDto.Id = alert.Id;
            alertDto.CreatedAt = alert.CreatedAt;
            alertDto.Acknowledged = alert.Acknowledged;

            return alertDto;
        }

        
        public async Task<bool> UpdateAlertAsync(int id, AlertDto alertDto)
        {
            var existingAlert = await _context.Alerts.FindAsync(id);
            if (existingAlert == null) return false;

            existingAlert.Type = Enum.Parse<AlertType>(alertDto.Type);
            existingAlert.Message = alertDto.Message;
            existingAlert.Severity = Enum.Parse<SeverityLevel>(alertDto.Severity);
            existingAlert.Acknowledged = alertDto.Acknowledged;
            existingAlert.AcknowledgedAt = alertDto.AcknowledgedAt;
            existingAlert.DriverId = alertDto.DriverId;
            existingAlert.TripId = alertDto.TripId;
            existingAlert.ViolationId = alertDto.ViolationId;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                return false;
            }
        }

       
        public async Task<bool> DeleteAlertAsync(int id)
        {
            var alert = await _context.Alerts.FindAsync(id);
            if (alert == null) return false;

            _context.Alerts.Remove(alert);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
