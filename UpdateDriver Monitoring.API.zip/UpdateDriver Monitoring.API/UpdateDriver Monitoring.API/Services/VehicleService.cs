﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Services
{
    public class VehicleService
    {
        private readonly DriverMonitoringContext _context;

        public VehicleService(DriverMonitoringContext context)
        {
            _context = context;
        }

        public async Task<List<Vehicle>> GetAllVehiclesAsync()
        {
            return await _context.Vehicles.AsNoTracking().ToListAsync();
        }

        public async Task<Vehicle?> GetVehicleByIdAsync(int id)
        {
            return await _context.Vehicles.FindAsync(id);
        }

        public async Task<Vehicle> CreateVehicleAsync(Vehicle vehicle)
        {
            _context.Vehicles.Add(vehicle);
            await _context.SaveChangesAsync();
            return vehicle;
        }

        public async Task<bool> UpdateVehicleAsync(int id, Vehicle vehicle)
        {
            if (id != vehicle.Id) return false;

            _context.Entry(vehicle).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                return true;
            }
            catch (DbUpdateConcurrencyException)
            {
                var exists = await _context.Vehicles.AnyAsync(e => e.Id == id);
                if (!exists) return false;
                throw;
            }
        }

        public async Task<bool> DeleteVehicleAsync(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null) return false;

            _context.Vehicles.Remove(vehicle);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
