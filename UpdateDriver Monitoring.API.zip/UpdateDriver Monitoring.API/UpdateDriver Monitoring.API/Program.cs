using Microsoft.EntityFrameworkCore;
using System.Text.Json.Serialization;
using UpdateDriverMonitoring.API.Data;
using UpdateDriverMonitoring.API.Services;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddDbContext<DriverMonitoringContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


builder.Services.AddScoped<AlertService>();
builder.Services.AddScoped<ReportsService>();
builder.Services.AddScoped<DriverService>();
builder.Services.AddScoped<VehicleService>();
builder.Services.AddScoped<TripsService>();
builder.Services.AddScoped<NotificationService>();
builder.Services.AddScoped<LocationService>();
builder.Services.AddScoped<ViolationService>();


builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    });

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy =>
        {
            policy.AllowAnyOrigin()
                  .AllowAnyMethod()
                  .AllowAnyHeader();
        });
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();


app.UseCors("AllowAll");


app.MapControllers();

app.Run();
