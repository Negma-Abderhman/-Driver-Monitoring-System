﻿using Microsoft.EntityFrameworkCore;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Data
{
    public class DriverMonitoringContext : DbContext
    {
        public DriverMonitoringContext(DbContextOptions<DriverMonitoringContext> options)
            : base(options)
        {
        }

        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Vehicle> Vehicles { get; set; }
        public DbSet<Trip> Trips { get; set; }
        public DbSet<Location> Locations { get; set; }
        public DbSet<Violation> Violations { get; set; }
        public DbSet<Alert> Alerts { get; set; }
        public DbSet<Notification> Notifications { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            
            modelBuilder.Entity<Trip>()
                .HasOne(t => t.Driver)
                .WithMany(d => d.Trips)
                .HasForeignKey(t => t.DriverId)
                .OnDelete(DeleteBehavior.Cascade);

            
            modelBuilder.Entity<Trip>()
                .HasOne(t => t.Vehicle)
                .WithMany(v => v.Trips)
                .HasForeignKey(t => t.VehicleId)
                .OnDelete(DeleteBehavior.NoAction);

           
            modelBuilder.Entity<Location>()
                .HasOne(l => l.Trip)
                .WithMany(t => t.Locations)
                .HasForeignKey(l => l.TripId)
                .OnDelete(DeleteBehavior.Cascade);

            
            modelBuilder.Entity<Violation>()
                .HasOne(v => v.Driver)
                .WithMany(d => d.Violations)
                .HasForeignKey(v => v.DriverId)
                .OnDelete(DeleteBehavior.Cascade);

             
            modelBuilder.Entity<Violation>()
                .HasOne(v => v.Trip)
                .WithMany(t => t.Violations)
                .HasForeignKey(v => v.TripId)
                .OnDelete(DeleteBehavior.NoAction);

            
            modelBuilder.Entity<Alert>()
                .HasOne(a => a.Driver)
                .WithMany(d => d.Alerts)
                .HasForeignKey(a => a.DriverId)
                .OnDelete(DeleteBehavior.Cascade);

            
            modelBuilder.Entity<Notification>()
                .HasOne(n => n.Driver)
                .WithMany(d => d.Notifications)
                .HasForeignKey(n => n.DriverId)
                .OnDelete(DeleteBehavior.Cascade);

            
            modelBuilder.Entity<Violation>()
                .Property(v => v.FineAmount)
                .HasColumnType("decimal(18,2)");
        }
    }
}
