﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Models
{
    public enum VehicleStatus
    {
        Active,
        Inactive,
        UnderMaintenance
    }

    public class Vehicle
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Plate number is required.")]
        [MaxLength(20, ErrorMessage = "Plate number cannot exceed 20 characters.")]
        public string PlateNumber { get; set; }

        [Required(ErrorMessage = "Make is required.")]
        [MaxLength(60, ErrorMessage = "Make cannot exceed 60 characters.")]
        public string Make { get; set; }

        [Required(ErrorMessage = "Model is required.")]
        [MaxLength(60, ErrorMessage = "Model cannot exceed 60 characters.")]
        public string Model { get; set; }

        [Range(1900, 2100, ErrorMessage = "Year must be between 1900 and 2100.")]
        public int? Year { get; set; }

        [MaxLength(30, ErrorMessage = "Color cannot exceed 30 characters.")]
        public string Color { get; set; }

        [MaxLength(50, ErrorMessage = "VIN cannot exceed 50 characters.")]
        public string VIN { get; set; }

        [Required(ErrorMessage = "Vehicle status is required.")]
        public VehicleStatus Status { get; set; } = VehicleStatus.Active;

        [Range(0, double.MaxValue, ErrorMessage = "Mileage must be a positive value.")]
        public double? MileageKm { get; set; }

        public DateTime? LastServiceDate { get; set; }

        public ICollection<Trip> Trips { get; set; } = new List<Trip>();
    }
}
