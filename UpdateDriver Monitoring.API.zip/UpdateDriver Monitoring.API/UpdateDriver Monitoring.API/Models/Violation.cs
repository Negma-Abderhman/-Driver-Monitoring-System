﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace UpdateDriverMonitoring.API.Models
{
    public enum ViolationType
    {
        Speeding,
        DistractedDriving,
        NoSeatBelt,
        PhoneUsage,
        Other
    }

    public enum SeverityLevel
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }

    public class Violation
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Violation type is required.")]
        public ViolationType Type { get; set; }

        [MaxLength(200)]
        public string Description { get; set; }

        [Required]
        public SeverityLevel Severity { get; set; } = SeverityLevel.Low;

        [Range(0, 100000)]
        public decimal? FineAmount { get; set; }

        [Required]
        public DateTime OccurredAt { get; set; } = DateTime.UtcNow;

        [Required]
        public int DriverId { get; set; }
        public Driver? Driver { get; set; }

        public int? TripId { get; set; }
        public Trip? Trip { get; set; }
    }

}
