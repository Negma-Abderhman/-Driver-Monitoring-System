﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UpdateDriverMonitoring.API.Models
{
    public enum NotificationType
    {
        Info,
        Warning,
        Critical
    }

    public class Notification
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(250)]
        public string Message { get; set; }

        [Required]
        public NotificationType Type { get; set; } = NotificationType.Info;

        public bool IsRead { get; set; } = false;

        [Required]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [MaxLength(100)]
        public string? CreatedBy { get; set; }

        public DateTime? ExpireAt { get; set; }

        [Required]
        public int DriverId { get; set; }
        public Driver Driver { get; set; }
    }
}
