﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UpdateDriverMonitoring.API.Models
{
    public class Location
    {
        public int Id { get; set; }

        [Range(-90, 90)]
        [Required]
        public double Latitude { get; set; }

        [Range(-180, 180)]
        [Required]
        public double Longitude { get; set; }

        [Range(0, 300)]
        public double? SpeedKph { get; set; }

        [Range(0, 360)]
        public double? Direction { get; set; }

        [Range(0, 1000)]
        public double? AccuracyMeters { get; set; }

        [Required]
        public DateTime RecordedAt { get; set; } = DateTime.UtcNow;

        [Required]
        public int TripId { get; set; }
        public Trip Trip { get; set; }
    }
}
