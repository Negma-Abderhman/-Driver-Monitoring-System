﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Models
{
    public enum TripStatus
    {
        Ongoing,
        Completed,
        Cancelled
    }

    public class Trip
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Start time is required")]
        public DateTime StartTime { get; set; }

        public DateTime? EndTime { get; set; }

        [Range(-90, 90, ErrorMessage = "Start latitude must be between -90 and 90")]
        public double? StartLatitude { get; set; }

        [Range(-180, 180, ErrorMessage = "Start longitude must be between -180 and 180")]
        public double? StartLongitude { get; set; }

        [Range(-90, 90, ErrorMessage = "End latitude must be between -90 and 90")]
        public double? EndLatitude { get; set; }

        [Range(-180, 180, ErrorMessage = "End longitude must be between -180 and 180")]
        public double? EndLongitude { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Distance must be a positive number")]
        public double? DistanceKm { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Average speed must be a positive number")]
        public double? AverageSpeedKph { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Max speed must be a positive number")]
        public double? MaxSpeedKph { get; set; }

        [Required(ErrorMessage = "Trip status is required")]
        public TripStatus Status { get; set; } = TripStatus.Ongoing;

        
        [Required(ErrorMessage = "DriverId is required")]
        public int DriverId { get; set; }
        public Driver Driver { get; set; }

        [Required(ErrorMessage = "VehicleId is required")]
        public int VehicleId { get; set; }
        public Vehicle Vehicle { get; set; }

        public ICollection<Location> Locations { get; set; } = new List<Location>();
        public ICollection<Violation> Violations { get; set; } = new List<Violation>();
        public ICollection<Alert> Alerts { get; set; } = new List<Alert>();

        
        public TimeSpan? Duration
        {
            get
            {
                if (EndTime.HasValue)
                {
                    return EndTime.Value - StartTime;
                }
                return null;
            }
        }
    }
}
