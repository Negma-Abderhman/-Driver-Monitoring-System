﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using UpdateDriverMonitoring.API.Models;

namespace UpdateDriverMonitoring.API.Models
{
    public enum DriverStatus
    {
        Active,
        Inactive,
        Suspended
    }

    public class Driver
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Full name is required")]
        [StringLength(120, MinimumLength = 3, ErrorMessage = "Full name must be between 3 and 120 characters")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "License number is required")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "License number must be between 5 and 50 characters")]
        public string LicenseNumber { get; set; }

        [Phone(ErrorMessage = "Invalid phone number format")]
        [StringLength(30, ErrorMessage = "Phone number cannot exceed 30 characters")]
        public string PhoneNumber { get; set; }

        [EmailAddress(ErrorMessage = "Invalid email address format")]
        [StringLength(120, ErrorMessage = "Email cannot exceed 120 characters")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Driver status is required")]
        public DriverStatus Status { get; set; } = DriverStatus.Active;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [Url(ErrorMessage = "Invalid URL format")]
        public string PhotoUrl { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Invalid date format")]
        public DateTime? DateOfBirth { get; set; }

        
        public ICollection<Trip> Trips { get; set; } = new List<Trip>();
        public ICollection<Violation> Violations { get; set; } = new List<Violation>();
        public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
        public ICollection<Alert> Alerts { get; set; } = new List<Alert>();
    }
}
