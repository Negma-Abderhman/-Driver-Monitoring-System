﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UpdateDriverMonitoring.API.Models
{
    public enum AlertType
    {
        SpeedLimitExceeded,
        HarshBraking,
        HarshAcceleration,
        DrowsinessDetected,
        DeviceDisconnected,
        GeofenceBreach,
        Incident,
        Other
    }

    public class Alert
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Alert type is required.")]
        public AlertType Type { get; set; } = AlertType.Other;

        [MaxLength(250, ErrorMessage = "Message cannot exceed 250 characters.")]
        public string Message { get; set; }

        [Required(ErrorMessage = "Severity is required.")]
        public SeverityLevel Severity { get; set; } = SeverityLevel.Medium;

        [Required(ErrorMessage = "CreatedAt is required.")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public bool Acknowledged { get; set; } = false;

        public DateTime? AcknowledgedAt { get; set; }

        
        public int? DriverId { get; set; }
        public Driver Driver { get; set; }

        public int? TripId { get; set; }
        public Trip Trip { get; set; }

        public int? ViolationId { get; set; }
        public Violation Violation { get; set; }
    }
}
